package lk.kzone.teacher;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.webkit.CookieManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.ScrollView;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.content.Intent;
import android.net.Uri;
import android.view.Gravity;

public class MainActivity extends Activity {
    private WebView web;
    private LinearLayout home;
    private final Handler handler = new Handler();
    private static final String ADMIN_URL = "https://orange-resonance-c27f.sudarshanahm.workers.dev";
    private static final String TEACHER_URL = "https://crimson-frog-15f5.sudarshanahm.workers.dev";
    private int dp(float v){ return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(8,55,105));
        getWindow().setNavigationBarColor(Color.rgb(248,250,253));
        showSplash();
    }

    private GradientDrawable bg(int color, float radius){
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); return d;
    }
    private GradientDrawable strokeBg(int fill, int stroke, float radius){
        GradientDrawable d = bg(fill,radius); d.setStroke(dp(1),stroke); return d;
    }
    private TextView tv(String text,float size,int color,boolean bold){
        TextView t=new TextView(this); t.setText(text); t.setTextSize(size); t.setTextColor(color); t.setGravity(Gravity.CENTER);
        if(bold) t.setTypeface(Typeface.DEFAULT,Typeface.BOLD); return t;
    }

    private void showSplash(){
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(dp(24),dp(52),dp(24),dp(28)); root.setBackgroundColor(Color.rgb(246,250,255));

        TextView crest=tv("📚",38,Color.WHITE,true); crest.setGravity(Gravity.CENTER); crest.setBackground(bg(Color.WHITE,48));
        crest.setTextColor(Color.rgb(8,81,161));
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(dp(88),dp(88)); cp.setMargins(0,dp(12),0,dp(16)); root.addView(crest,cp);

        LinearLayout brand=new LinearLayout(this); brand.setGravity(Gravity.CENTER); brand.setOrientation(LinearLayout.HORIZONTAL);
        TextView k=tv("K",62,Color.rgb(7,81,161),true); k.setShadowLayer(dp(2),dp(2),dp(2),Color.rgb(218,169,25));
        TextView zone=tv(" ZONE",43,Color.rgb(18,59,109),true); brand.addView(k); brand.addView(zone);
        root.addView(brand,new LinearLayout.LayoutParams(-1,dp(72)));

        TextView office=tv("KEKIRAWA ZONAL EDUCATION OFFICE",13,Color.rgb(18,59,109),true); office.setLetterSpacing(.06f); root.addView(office,new LinearLayout.LayoutParams(-1,dp(34)));
        TextView line=tv("────────  📖  ────────",16,Color.rgb(218,169,25),false); root.addView(line,new LinearLayout.LayoutParams(-1,dp(35)));
        TextView title=tv("Salary Increment Management System",20,Color.rgb(18,59,109),true); root.addView(title,new LinearLayout.LayoutParams(-1,dp(34)));
        TextView sub=tv("Teacher Information & Increment Status",14,Color.rgb(75,96,120),false); root.addView(sub,new LinearLayout.LayoutParams(-1,dp(28)));

        LinearLayout chips=new LinearLayout(this); chips.setGravity(Gravity.CENTER); chips.setOrientation(LinearLayout.HORIZONTAL); chips.setPadding(0,dp(18),0,dp(8));
        String[] labels={"👥
Teachers","📄
Increment","📊
Status"};
        for(String s:labels){ TextView c=tv(s,11,Color.rgb(24,78,133),true); c.setBackground(strokeBg(Color.WHITE,Color.rgb(225,232,241),16)); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(58),1); p.setMargins(dp(4),0,dp(4),0); chips.addView(c,p); }
        root.addView(chips,new LinearLayout.LayoutParams(-1,dp(74)));

        TextView msg=tv("Together for a Better Education in Kekirawa",14,Color.rgb(18,59,109),true); msg.setTypeface(Typeface.create("sans",Typeface.ITALIC)); LinearLayout.LayoutParams mp=new LinearLayout.LayoutParams(-1,dp(34)); mp.setMargins(0,dp(18),0,0); root.addView(msg,mp);
        setContentView(root);
        handler.postDelayed(this::showHome,1500);
    }

    private void showHome(){
        ScrollView scroll=new ScrollView(this); scroll.setFillViewport(true); scroll.setBackgroundColor(Color.rgb(246,250,255));
        home=new LinearLayout(this); home.setOrientation(LinearLayout.VERTICAL); home.setGravity(Gravity.CENTER_HORIZONTAL); home.setPadding(dp(22),dp(24),dp(22),dp(30));

        LinearLayout hero=new LinearLayout(this); hero.setOrientation(LinearLayout.VERTICAL); hero.setGravity(Gravity.CENTER); hero.setPadding(dp(18),dp(20),dp(18),dp(22));
        GradientDrawable heroBg=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{Color.rgb(8,63,121),Color.rgb(24,118,194)}); heroBg.setCornerRadius(dp(28)); hero.setBackground(heroBg);
        TextView mini=tv("📚",28,Color.WHITE,true); mini.setBackground(bg(Color.WHITE,42)); mini.setTextColor(Color.rgb(8,81,161)); hero.addView(mini,new LinearLayout.LayoutParams(dp(62),dp(62)));
        LinearLayout mark=new LinearLayout(this); mark.setGravity(Gravity.CENTER); TextView hk=tv("K",49,Color.WHITE,true); hk.setShadowLayer(dp(2),dp(2),dp(2),Color.rgb(224,173,24)); TextView hz=tv(" ZONE",34,Color.WHITE,true); mark.addView(hk); mark.addView(hz); hero.addView(mark,new LinearLayout.LayoutParams(-1,dp(56)));
        TextView ho=tv("KEKIRAWA ZONAL EDUCATION OFFICE",11,Color.WHITE,true); ho.setLetterSpacing(.05f); hero.addView(ho,new LinearLayout.LayoutParams(-1,dp(28)));
        TextView hs=tv("Teacher & Admin App",14,Color.rgb(230,241,255),false); hero.addView(hs,new LinearLayout.LayoutParams(-1,dp(28)));
        home.addView(hero,new LinearLayout.LayoutParams(-1,dp(235)));

        TextView welcome=tv("Welcome to K ZONE",23,Color.rgb(18,59,109),true); LinearLayout.LayoutParams wp=new LinearLayout.LayoutParams(-1,dp(40)); wp.setMargins(0,dp(22),0,0); home.addView(welcome,wp);
        TextView hint=tv("Please select your login",13,Color.rgb(110,125,142),false); home.addView(hint,new LinearLayout.LayoutParams(-1,dp(25)));

        Button teacher=button("👨‍🏫   Teacher Login",Color.rgb(23,105,170),Color.WHITE); teacher.setOnClickListener(v->openWeb(TEACHER_URL)); LinearLayout.LayoutParams tp=buttonParams(); tp.setMargins(0,dp(20),0,0); home.addView(teacher,tp);
        Button admin=button("🛡️   Admin Login",Color.WHITE,Color.rgb(18,59,109)); admin.setBackground(strokeBg(Color.WHITE,Color.rgb(23,105,170),15)); admin.setOnClickListener(v->openWeb(ADMIN_URL)); LinearLayout.LayoutParams ap=buttonParams(); ap.setMargins(0,dp(12),0,0); home.addView(admin,ap);

        TextView note=tv("එකම K ZONE App එකෙන් Teacher සහ Admin
Login",13,Color.rgb(110,125,142),false); LinearLayout.LayoutParams np=new LinearLayout.LayoutParams(-1,dp(55)); np.setMargins(0,dp(18),0,0); home.addView(note,np);
        TextView footer=tv("Quality Education for a Brighter Tomorrow",13,Color.rgb(18,59,109),true); footer.setTypeface(Typeface.create("sans",Typeface.ITALIC)); home.addView(footer,new LinearLayout.LayoutParams(-1,dp(36)));

        scroll.addView(home); setContentView(scroll);
    }

    private Button button(String text,int color,int textColor){ Button b=new Button(this); b.setText(text); b.setTextSize(16); b.setTextColor(textColor); b.setAllCaps(false); b.setGravity(Gravity.CENTER); b.setTypeface(Typeface.DEFAULT,Typeface.BOLD); b.setMinHeight(0); b.setMinimumHeight(0); b.setPadding(dp(12),0,dp(12),0); b.setBackground(bg(color,15)); return b; }
    private LinearLayout.LayoutParams buttonParams(){ return new LinearLayout.LayoutParams(-1,dp(56)); }

    private void openWeb(String url){
        web=new WebView(this); web.setBackgroundColor(Color.WHITE);
        web.setWebViewClient(new WebViewClient(){ @Override public boolean shouldOverrideUrlLoading(WebView view,String url){ if(url.startsWith("https://")||url.startsWith("http://")) return false; try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(url)));}catch(Exception ignored){} return true; }});
        WebSettings s=web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setDatabaseEnabled(true); s.setAllowFileAccess(false); s.setAllowContentAccess(true); CookieManager.getInstance().setAcceptCookie(true); CookieManager.getInstance().setAcceptThirdPartyCookies(web,true); web.loadUrl(url); setContentView(web);
    }
    @Override public void onBackPressed(){ if(web!=null&&web.canGoBack()) web.goBack(); else showHome(); }
}
