package lk.kzone.teacher;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.CookieManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.content.Intent;
import android.net.Uri;

public class MainActivity extends Activity {
    private WebView web;
    private LinearLayout home;
    private static final String ADMIN_URL = "https://orange-resonance-c27f.sudarshanahm.workers.dev";
    private static final String TEACHER_URL = "https://crimson-frog-15f5.sudarshanahm.workers.dev";

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        showHome();
    }

    private void showHome() {
        home = new LinearLayout(this);
        home.setOrientation(LinearLayout.VERTICAL);
        home.setGravity(Gravity.CENTER_HORIZONTAL);
        home.setPadding(40, 70, 40, 40);
        home.setBackgroundColor(Color.rgb(238,246,251));

        TextView title = new TextView(this);
        title.setText("K ZONE");
        title.setTextSize(34);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setTextColor(Color.rgb(13,119,184));
        title.setGravity(Gravity.CENTER);
        home.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView sub = new TextView(this);
        sub.setText("කැකිරාව කලාප අධ්‍යාපන කාර්යාලය\nTeacher & Admin App");
        sub.setTextSize(17);
        sub.setGravity(Gravity.CENTER);
        sub.setTextColor(Color.DKGRAY);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, -2);
        sp.setMargins(0, 12, 0, 45);
        home.addView(sub, sp);

        Button teacher = button("👨‍🏫  Teacher Login");
        teacher.setOnClickListener(v -> openWeb(TEACHER_URL));
        home.addView(teacher, buttonParams());

        Button admin = button("👨‍💼  Admin Login");
        admin.setOnClickListener(v -> openWeb(ADMIN_URL));
        LinearLayout.LayoutParams ap = buttonParams();
        ap.setMargins(0, 18, 0, 0);
        home.addView(admin, ap);

        TextView note = new TextView(this);
        note.setText("එකම K ZONE App එකෙන් Teacher සහ Admin Login");
        note.setTextSize(14);
        note.setGravity(Gravity.CENTER);
        note.setTextColor(Color.GRAY);
        LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(-1, -2);
        np.setMargins(0, 45, 0, 0);
        home.addView(note, np);

        setContentView(home);
    }

    private Button button(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(17);
        b.setAllCaps(false);
        return b;
    }

    private LinearLayout.LayoutParams buttonParams() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, 60);
        return p;
    }

    private void openWeb(String url) {
        web = new WebView(this);
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                if (url.startsWith("https://") || url.startsWith("http://")) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); } catch(Exception ignored) {}
                return true;
            }
        });
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true);
        web.loadUrl(url);
        setContentView(web);
    }

    @Override public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else showHome();
    }
}
